package org.aguzman.springcloud.msvc.cursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
